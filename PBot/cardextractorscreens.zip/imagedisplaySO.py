# -*- coding: utf-8 -*-
"""
Created on Thu Dec 27 23:54:45 2012

@author: Mark
"""

import os,sys
from PyQt4 import QtGui
os.chdir("C:\\Users\\Mark\\Documents\\pbot Testing\\images")

app = QtGui.QApplication(sys.argv)
window = QtGui.QMainWindow()
window.setGeometry(0, 0, 400, 200)

pic = QtGui.QLabel(window)
pic.setGeometry(10, 10, 400, 100)
#use full ABSOLUTE path to the image, not relative
pic.setPixmap(QtGui.QPixmap(os.getcwd() + "\\2h.png"))

print os.getcwd()

window.show()
sys.exit(app.exec_())