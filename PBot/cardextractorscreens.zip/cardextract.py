# -*- coding: utf-8 -*-
"""
Created on Fri Dec 28 16:37:02 2012

@author: Mark
"""

import os, sys

from PIL import Image, ImageQt

from PyQt4 import QtGui

def extractCards(path):
    

    """
    extractCards takes a path pointing to a directory full of screenshots
    from the CarbonPoker client and returns an array of Qt QImages of each
    individual card.
    
    extractCards expects that each screenshot is of the carbonPoker client
    set to "default" window size.

    """
    
    os.chdir(path)    
    imgFileList = os.listdir(path)
    
    cardQtImages = []

    topLeftX = [277, 328, 380, 431, 482]
    topLeftY = 209
    
    squareSize = 42
    
    
    for imgFile in imgFileList:
        
        print "Opening " + str(imgFile)        
        img = Image.open(imgFile)
        
        #For some reason, some of my screenshots were RGBA
        #This tests and converts, if necessary        
        if img.mode != "RGB":
            print "Converting " + str(imgFile) + " to RGB ... "
            img = img.convert("RGB")
            print "Converted!"
            
        #pix = img.load()
        
        #Test to see how many cards are present for extraction
        #These three pixel locations should be pure white if there is
        #a card present there. First we test river, then turn, then flop
        
        if sum(img.getpixel((510, 220))) == 255*3:
            print "5 cards detected"
            cardsPresent = 5
            
        elif sum(img.getpixel((460, 220))) == 255*3:
            print "4 cards detected"
            cardsPresent = 4
            
        elif sum(img.getpixel((410, 220))) == 255*3:
            print "3 cards detected"
            cardsPresent = 3
            
        else:
            print "No cards detected in image " + str(imgFile)
            print "Aborting card extract for this image"
            break
        
        for i in range(cardsPresent):
            
            cardRegion = (topLeftX[i], topLeftY, topLeftX[i] + squareSize, \
                topLeftY + squareSize)
            
            cardImg = img.crop(cardRegion)
                
            cardQtImages.append(ImageQt.ImageQt(cardImg))
            

    print str(len(cardQtImages)) + " cards extracted!"
    
    return cardQtImages
    
class MyWidget(QtGui.QWidget):

    def __init__(self):
        
        super(MyWidget, self).__init__()
        
        self.initUI()
        
        
    def initUI(self):
        
        txtBoxCardName = QtGui.QLineEdit()
        
        picLabel = QtGui.QLabel()
        picLabel.setObjectName("imgDisplay")
        
        saveBtn = QtGui.QPushButton("Save/Next")
        saveBtn.setObjectName("saveBtn")        
        
        generateBtn = QtGui.QPushButton("Generate Cards")
#        generateBtn.clicked.connect(extractCards)
#        generateBtn.clicked.emit("C:\\Users\\Mark\\Documents\\pbot Testing\\boardimages\\")
        
        qlabelStyleSheet = "QLabel { background-color : rgb(230, 230, 240); }"        
        
        picLabel.setStyleSheet(qlabelStyleSheet)
        picLabel.setFixedSize(180, 180)
        
        txtBoxCardName.setFixedWidth(30)
        txtBoxCardName.setMaxLength(3)
        
        txtBoxPath = QtGui.QLineEdit()
        txtBoxPath.setObjectName("pathText")
        
        btnBrowse = QtGui.QPushButton("...")
        btnBrowse.setObjectName("browseBtn")
        
        btnBrowse.setFixedWidth(25)
        
        #Horizontal Layout
        #Input and Save Button
        hBoxInputSave = QtGui.QHBoxLayout()
      
        hBoxInputSave.addStretch(1)        
        hBoxInputSave.addWidget(txtBoxCardName)
        hBoxInputSave.addWidget(saveBtn)
        
        #Horizontal Layout
        #Path stuff
        
        hBoxPath = QtGui.QHBoxLayout()
        
        hBoxPath.addWidget(txtBoxPath)
        hBoxPath.addWidget(btnBrowse)        
       
        #Vertical Layout        
        vBox = QtGui.QVBoxLayout()
        
        #vBox.addStretch(1)
        vBox.addWidget(picLabel)
        vBox.addLayout(hBoxInputSave)
        vBox.addWidget(generateBtn)
        
        vBox.addLayout(hBoxPath)
        
        btnBrowse.clicked
        
        self.setLayout(vBox)
        
        self.setGeometry(350, 350, 300, 200)
        self.setFixedSize(self.sizeHint())

        self.setWindowTitle("CardEx")
        
        self.show()
        
def main():
    
    app = QtGui.QApplication(sys.argv)
    
    myWidget = MyWidget()
    
    
    extractCards("C:\\Users\\Mark\\Documents\\pbot Testing\\boardimages\\")

    sys.exit(app.exec_())   
    
if __name__ == '__main__':
    main()
    

        